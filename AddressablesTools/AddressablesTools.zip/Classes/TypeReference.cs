﻿using System;

namespace AddressablesTools.Classes
{
    public class TypeReference
    {
        public Guid Clsid { get; set; }

        public TypeReference(Guid clsid)
        {
            Clsid = clsid;
        }
    }
}
