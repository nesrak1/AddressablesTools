﻿namespace AddressablesTools.Classes
{
    public class Hash128
    {
        public string Value { get; set; }

        public Hash128(string value)
        {
            Value = value;
        }
    }
}
