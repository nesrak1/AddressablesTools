﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AddressablesTools.JSON
{
#pragma warning disable IDE1006
    internal class ObjectInitializationDataJson
    {
        public string m_Id { get; set; }
        public SerializedTypeJson m_ObjectType { get; set; }
        public string m_Data { get; set; }
    }
#pragma warning restore IDE1006
}
