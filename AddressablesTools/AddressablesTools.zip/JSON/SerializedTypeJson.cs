﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AddressablesTools.JSON
{
#pragma warning disable IDE1006
    internal class SerializedTypeJson
    {
        public string m_AssemblyName { get; set; }
        public string m_ClassName { get; set; }
    }
#pragma warning restore IDE1006
}
